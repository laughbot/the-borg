# The Borg: codice attuale (per leggerlo e scrivere un nuovo minigioco)

Gioco social 3D per telefono, tutto nel browser. Three.js r150 (lib/three.min.js), nessun build:
index.html carica gli script di js/ in ordine. Le immagini delle carte (img/) non sono incluse.
Per provarlo: apri un server locale nella cartella (es. `python3 -m http.server`) e vai su index.html.

## Come e' fatto un minigioco (esempio: js/kart.js, js/paintball.js)
- Un solo file JS in una funzione `(function(){ ... })();` che usa `const B = window.B3, T = B.T` (T = THREE).
- Ha una scena 3D sua e la sua interfaccia (HUD creato da JS); il resto del gioco resta fermo.
- Espone un oggetto, es. `B.Kart = { attivo, avvia(), esci() }`.
- Si apre da una "porta" in Sala Giochi (js/sala3d.js): `{ gioco: 'kart', ... }`,
  e main.js `usaPorta` chiama `avvia()`.
- Comandi touch: joystick a sinistra `B.app.joy.x / B.app.joy.y`, pulsanti a destra.
  Sparatutto: comandi condivisi in js/comandi-fps.js.
- Monete del giocatore: `B.Eco.coins`, `B.Eco.add(n)`, `B.Eco.spendi(n)` (js/arredi.js).
- Telefono in orizzontale: `B.orienta(true)` all'avvio, `B.orienta(false)` all'uscita.

## Per il nuovo minigioco (Borg Dungeon)
- 3D con Three.js r150, niente altre librerie.
- Un solo file, es. `js/dungeon.js`, con `B.Dungeon = { attivo, avvia(), esci() }`.
- A fine partita dare le monete con `B.Eco.add(n)`.
